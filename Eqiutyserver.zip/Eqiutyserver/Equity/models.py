from django.db import models

class Equity(models.Model):
    equity_exposure = models.IntegerField(max_length=4)
    balanced = models.IntegerField(max_length=4)
    debt = models.IntegerField(max_length=4)


