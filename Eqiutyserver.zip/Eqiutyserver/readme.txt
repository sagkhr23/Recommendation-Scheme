I have implemented the code using J-query, HTML, CSS, AngularJS, and server was built on Django, 

The algorithm I have constructed is as follows:
1.
If user clicks in recommended section then It keeps the percentage to  be decrease by some random value and then it goes to a different category according to the present percentage of equity.and if user is trying to click on the liquid or debt schemes when the equity percent is below 20% then teh recommended section shows the equity exposure section in the recommanded section.

2. 
If user clicks on the other schemes section then after some clicks it would show them their clicked scheme in the recommended section.
