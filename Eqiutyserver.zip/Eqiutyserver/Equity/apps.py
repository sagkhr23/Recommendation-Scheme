from django.apps import AppConfig


class EquityConfig(AppConfig):
    name = 'Equity'
